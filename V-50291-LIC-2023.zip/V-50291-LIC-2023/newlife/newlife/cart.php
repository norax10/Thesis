
 <!DOCTYPE html>
<?php
   include "connection.php";
        
 session_start();

if (!isset($_SESSION['u_email'])) {
	
	 echo "<script>alert('Please Login First!!!!!!')</script>";
				 	echo"<script>window.open('login.php','_self')</script>";
  
}
else{
$x=$_GET["uid"];
echo $x;
$y=$_SESSION['u_id'];
  $sql = "SELECT * FROM item_master WHERE it_id='$x'  ";
		
		$result = mysqli_query($conn,$sql);
		
		if(mysqli_num_rows($result) > 0)
	{
			while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
			{
				$sh_id = $row['sh_id'];
				$subc_id = $row['subc_id'];
				$price = $row['it_price'];
				$price = $row['it_price'];
			}
	}
		
		
date_default_timezone_set('Asia/Kolkata');

$date = date('d/m/Y h:i:sa', time());


  $sql1 = "SELECT * FROM cart WHERE it_id='$x' and cust_id='$y' ";
		
		$result1 = mysqli_query($conn,$sql1);
		
		if(mysqli_num_rows($result1) > 0)
	{
			 echo "<script>alert('Selected Product already in Cart!!!!!!')</script>";
				 	echo"<script>window.open('index.php','_self')</script>";
	}
  
  
  
  else{

  

      $conn->query("INSERT INTO `cart`(`cust_id`, `sh_id`,`subc_id`,`it_id`,`price`,`qty`) VALUES('$y','$sh_id','$subc_id','$x','$price','1')");
	  
	   echo "<script>alert('Product Added to Cart!!!!!!')</script>";
				 	echo"<script>window.open('index.php','_self')</script>";
      
 
  }



}

  
        
?>
 
 
