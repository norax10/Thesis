 
<?php

include 'connection.php';

$user_id=$_GET['uid'];


$q = "SELECT * from item_master where it_id='$user_id' and it_status=1";
$data = mysqli_query($conn, $q);
$result = mysqli_num_rows($data);

?>
<html>
 
<?php include('head.php');?>
	
<body>
<!-- header -->
  <?php include('header.php');?>
		
<!-- //navigation -->
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				
				
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!--- groceries --->
	<div class="products">
		<div class="container">
			
			<div class="col-md-8 products-right">
					
			
			<div class="agile_top_brands_grids">
			<?php
			
			
			$q3 = "SELECT * from item_master where it_id='$user_id'";
			$data3 = mysqli_query($conn, $q3);
			$result3 = mysqli_num_rows($data3);

		   //}

			if ($result3 != 0) {
 
                      $i = 1;
                      while ($total3 = mysqli_fetch_assoc($data3)) { ?>
		
			
					<div class="col-md-4 top_brand_left">
						<div class="hover14 column">
							<div class="agile_top_brand_left_grid">
								
								<div class="agile_top_brand_left_grid1">
								<a class="button" href="viewmoredetails.php?uid=<?php echo $total3["it_id"]; ?>&shid=<?php echo $user_id ?>">
									<figure>
										<div class="snipcart-item block">
											<div class="snipcart-thumb">
												<img title=" " alt="Product Image" src="./shopowner/<?php echo $total3["im1"]; ?>" height="150px"> 	
												<p><?php echo $total3["it_name"]; ?></p>
												<h4>Rs. <?php echo $total3["it_price"]; ?> /- </h4>
											</div>
											<div class="snipcart-details top_brand_home_details">
												
												<a class="button" href="viewmoredetails.php?uid=<?php echo $total3["it_id"]; ?>&shid=<?php echo $user_id ?>"><input type="button" name="submit" value="View Details" class="button"></a>
											</div>
										</div>
									</figure>
									</a>
								</div>
							</div>
						</div>
					</div>
  <?php  } } 
  
  
  ?>
					
					
						<div class="clearfix"> </div>
				</div>
		</div>
	</div>
	</div> 
<!--- groceries --->
<!-- //footer -->

   <?php include('footer.php');?>
</body>
</html>