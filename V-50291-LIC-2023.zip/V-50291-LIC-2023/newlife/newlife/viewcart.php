
<!DOCTYPE html>
<?php
include 'connection.php';
session_start();
$a=$_SESSION['u_id'];

?>
<html>
<script src="js/jquery-1.11.1.min.js"></script>
<head>
<?php include('head.php');?>
	
<body>
<!-- header -->
  <?php include('header.php');?>
		<?php if(isset($_GET['delete'])){
                   
                        $it_id=$_GET['delete'];

                      $select_query= "delete from cart where it_id=$it_id and cust_id=$a";
                      $select_query_run =     mysqli_query($conn,$select_query);
           }


 if(isset($_GET['upplus'])){
                   
                        $it_id=$_GET['upplus'];

                      $select_query= "update cart set qty=qty+1 where it_id=$it_id and cust_id=$a";
                      $select_query_run =     mysqli_query($conn,$select_query);
           }

  if(isset($_GET['upminus'])){
                   
                        $it_id=$_GET['upminus'];

                      $select_query= "update cart set qty=qty-1 where it_id=$it_id and cust_id=$a";
                      $select_query_run =     mysqli_query($conn,$select_query);
           }
		   ?>
<!-- //navigation -->
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">CheckOut</li>
			</ol>
		</div>
	</div>
					 <?php
$q6 = "SELECT a.*,b.* from cart as a,item_master as b  where a.cust_id='$a' and a.it_id=b.it_id";
$data6 = mysqli_query($conn, $q6);
$result6 = mysqli_num_rows($data6)

?>
	<div class="checkout">
		<div class="container">
			<h2>Your shopping Bag contains: <span><?php echo $result6; ?> Products</span></h2>
			<div class="checkout-right">
				<table class="timetable_sub">
					<thead>
						<tr>
							<th>SL No.</th>	
							<!--th>Shop Name</th--->
							<th>Product</th>
							<th>Quantity</th>
							<th>Product Name</th>
						
							<th>Unit Price</th>
								<th>Sub Price</th>
							<th>Remove</th>
						</tr>
					</thead>
					
					
					 <?php
$q = "SELECT a.*,b.* from cart as a,item_master as b  where a.cust_id='$a' and a.it_id=b.it_id";
$data = mysqli_query($conn, $q);
$result = mysqli_num_rows($data);
                    if ($result != 0) {
 
                      $i = 1;
                      while ($total = mysqli_fetch_assoc($data)) { ?>
					<tr class="rem1">
						<td class="invert"><?php echo $i ?></td>
							
						
						<td class="invert-image" width="30%"><a href="#"><img src="./student/<?php echo $total["im1"]; ?>" alt=" " class="img-responsive"  width="50px" height="50px" /></a></td>
						<td><a href="viewcart.php?upminus=<?php echo $total['it_id'];?>" class="btn btn-sm btn-primary">-</a>
							<input type="text" value="<?php echo $total['qty'];?>" name="qty" style="width:30px;"/ readonly>	
							<a href="viewcart.php?upplus=<?php echo $total['it_id'];?>" class="btn btn-sm btn-primary">+</a></td>
						<td class="invert"><?php echo $total["it_name"]; ?> </td>
						
						<td class="invert"><?php echo $total["it_price"]; ?> /-</td>
						<td class="invert"><?php echo $t=$total["qty"]* $total["it_price"]; ?> /-</td>
							 <td>
					      	<a href="viewcart.php?delete=<?php echo $total['it_id'];?>" class="btn btn-sm btn-warning"   onclick="return confirm('Are You Sure Delete Item?');"><i class="fa fa-trash" aria-hidden="true"></i></a>
							 </td>
					
					</tr>
					
				
				<?php $i++;} } ?>
								
				</table>
			</div>
			<?php  $query1="SELECT SUM(price*qty) as price FROM cart where cust_id='$a'";
		
		 		 $result1 = mysqli_query($conn,$query1);
				 $row1=mysqli_fetch_array($result1);
				 if($row1['price']!=0){
					$tot_amt = $row1['price'];
				?>
				<h3 style="margin-left: 72%">Total Amount:&nbsp;<?php echo $tot_amt;?> /-</h3>
			<div class="checkout-left">	
				
					<a href="index.php" style="color:white;" class="btn btn-primary">Continue Shopping</a>
				
					
			
<input type="hidden" name="tot_amt" value="<?php echo $tot_amt; ?>" id="total_amount">
					 <input type="hidden" name="c_firstname" value="<?php echo $_SESSION['u_fname'];?>" id="customer_name"> 
					 <input type="hidden" name="c_email" value="<?php echo $_SESSION['u_email'];?>" id="c_email"> 
					 
					 <a href="callback.php?u_id=<?php echo $_SESSION['u_id'];?>" style="color:white; margin-left:75%;" class="btn btn-primary" >Confirm Order</a><?php  }?>
					 
					 
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!---script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script type="text/javascript">
   jQuery(document).on('click', '#razor-pay-now', function (e) { 
     e.preventDefault();
     //alert("button click");
			   var total_amount = $('#total_amount').val();
			 var customer_name = $('#customer_name').val();
			 var c_email = $('#c_email').val();
			    //var ca_id = $('#ca_id').val();
			   // var studio_name = $('#studio_name').val();
			   // var password = $('#password').val();
			   
				//var image = $("#ph_image").prop("files")[0];
				
				//alert(total_amount);

	var totalAmount = total_amount*100;

    var merchant_total = totalAmount;
    
    var merchant_order_id = "123";
    var currency_code_id = "INR";
     var options = {
    "key": "rzp_test_98Ozda9wzffKQ6",
    "amount": merchant_total, // 2000 paise = INR 20
    "name": "New life",
    "description": "New life Order",

    "currency" : "INR",
    "netbanking" : true,
    prefill: {
            name: customer_name,
           email: c_email,
            contact: 9898989898,

        },
     notes: {
            soolegal_order_id: merchant_order_id,
        },
    "handler": function (response){
    	  	//alert("inside ajax");
		  jQuery.ajax({
			    
		  url: 'http://192.168.0.141/newlife/callback.php',
	
            type: "POST",
            data: {
                razorpay_payment_id: response.razorpay_payment_id, 
                totalAmount : merchant_total,
                merchant_order_id : merchant_order_id,
                currency_code_id: currency_code_id,
				total_amount: total_amount,
				//photographer_contact: photographer_contact,
				//photographer_email: photographer_email,
				//studio_name: studio_name,
				//password: password,
				
				
            }, 
			
			  dataType: 'json',
              
			success: function (result) {
				//alert(result);
				alert('Thank You for Order.');
				 
              window.location.href = 'thank_you.php';
			  //   window.location = res.redirectURL;
			  
            }
			
        });
     
    },

    "theme": {
        "color": "#528FF0"
    }
  };
  
  var rzp1 = new Razorpay(options);
  rzp1.open();
  e.preventDefault();

} );

</script---->




   <?php include('footer.php');?>
</body>
</html>

