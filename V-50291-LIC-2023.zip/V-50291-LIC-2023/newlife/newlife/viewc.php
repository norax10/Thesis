
 <!DOCTYPE html>
<?php
   include "connection.php";
        
 session_start();

if (!isset($_SESSION['u_email'])) {
	
	 echo "<script>alert('Please Login First!!!!!To view cart!')</script>";
				 	echo"<script>window.open('login.php','_self')</script>";
  
}

 else
 
 {
	 
	 echo"<script>window.open('viewcart.php','_self')</script>";
	 
	 
 }
         
?>
 
 
