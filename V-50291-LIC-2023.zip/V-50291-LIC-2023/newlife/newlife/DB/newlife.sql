-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 03, 2023 at 08:54 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.3.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newlife`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `cust_id` int(5) NOT NULL,
  `sh_id` int(5) NOT NULL,
  `subc_id` int(11) NOT NULL DEFAULT 0,
  `it_id` int(5) NOT NULL,
  `price` int(5) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `cust_id`, `sh_id`, `subc_id`, `it_id`, `price`, `qty`) VALUES
(17, 1, 2, 0, 1, 10000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `item_master`
--

CREATE TABLE `item_master` (
  `it_id` int(5) NOT NULL,
  `c_id` int(5) DEFAULT NULL,
  `subc_id` int(5) DEFAULT NULL,
  `it_name` varchar(50) NOT NULL,
  `it_desc` varchar(200) NOT NULL,
  `it_price` int(11) NOT NULL,
  `im1` varchar(100) NOT NULL,
  `im2` varchar(100) DEFAULT NULL,
  `im3` varchar(100) DEFAULT NULL,
  `im4` varchar(100) DEFAULT NULL,
  `remark` varchar(50) NOT NULL,
  `it_status` int(5) NOT NULL,
  `sh_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `item_master`
--

INSERT INTO `item_master` (`it_id`, `c_id`, `subc_id`, `it_name`, `it_desc`, `it_price`, `im1`, `im2`, `im3`, `im4`, `remark`, `it_status`, `sh_id`) VALUES
(1, NULL, NULL, 'Computer', 'Dell Laptop', 10000, 'shop/asus.png', NULL, NULL, NULL, 'OK', 1, 2),
(2, NULL, NULL, 'Mouse', 'Optical Mouse', 120, 'shop/keyboard3.png', NULL, NULL, NULL, 'It is nice Mouse', 1, 2),
(3, NULL, NULL, 'Printer', 'It is inkjet printer', 15230, 'shop/secondhand.jpg', NULL, NULL, NULL, 'OK', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `o_id` int(11) NOT NULL,
  `order_number` int(11) NOT NULL,
  `cust_id` int(5) NOT NULL,
  `sh_id` int(5) NOT NULL,
  `subc_id` int(11) DEFAULT 0,
  `it_id` int(5) NOT NULL,
  `price` int(5) NOT NULL,
  `qty` int(11) NOT NULL,
  `ostatus` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`o_id`, `order_number`, `cust_id`, `sh_id`, `subc_id`, `it_id`, `price`, `qty`, `ostatus`) VALUES
(1, 1672399158, 3, 4, 0, 8, 1200, 1, 1),
(2, 1672399460, 3, 4, 0, 8, 1200, 1, 0),
(3, 1672399743, 4, 2, 0, 6, 2550, 1, 0),
(4, 1672399743, 4, 2, 0, 2, 250, 1, 0),
(5, 1672399979, 4, 3, 0, 9, 1200, 1, 0),
(6, 1672463678, 3, 2, 0, 1, 800, 1, 1),
(7, 1672465879, 4, 4, 0, 4, 10000, 1, 1),
(8, 1672479025, 4, 4, 0, 3, 600, 1, 0),
(9, 1672479025, 4, 2, 0, 1, 900, 1, 0),
(10, 1672640787, 4, 2, 0, 2, 700, 1, 0),
(11, 1672640787, 4, 4, 0, 6, 700, 1, 0),
(12, 1672640787, 4, 5, 0, 3, 13000, 1, 0),
(13, 1672644787, 1, 2, 0, 1, 10000, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shopowner`
--

CREATE TABLE `shopowner` (
  `sh_id` int(5) NOT NULL,
  `sh_name` varchar(100) NOT NULL,
  `sh_oname` varchar(100) NOT NULL,
  `sh_address` varchar(200) NOT NULL,
  `sh_mob` varchar(12) NOT NULL,
  `sh_email` varchar(50) NOT NULL,
  `sh_pass` varchar(30) NOT NULL,
  `sh_image` varchar(300) NOT NULL,
  `sh_pan` varchar(300) NOT NULL,
  `sh_regim` varchar(300) NOT NULL,
  `sh_status` int(5) NOT NULL,
  `sharea` varchar(200) NOT NULL,
  `shpin` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shopowner`
--

INSERT INTO `shopowner` (`sh_id`, `sh_name`, `sh_oname`, `sh_address`, `sh_mob`, `sh_email`, `sh_pass`, `sh_image`, `sh_pan`, `sh_regim`, `sh_status`, `sharea`, `shpin`) VALUES
(2, 'Alka', 'Mr.Sachon', 'Fatehganj', '7418529630', 'seller@gmail.com', 'seller', 'shop/android.png', 'shop/angular.png', 'shop/banner.jpg', 1, 'Warshaw', 390001),
(3, 'Kumar Store', 'Mr.Rakesh', '12 New Market ', '9009595095', 'k@k.com', '147', 'shop/banner1.jpg', 'shop/g6.jpg', 'shop/g5.jpg', 1, 'Idogalia', 390009),
(4, 'Classic Fashion', 'Mr.Rahul', '2b Alkapuri', '9874561230', 'c@c.com', 'c', 'shop/empty_cart.jpg', 'shop/paper.jpg', 'shop/sub.png', 1, 'Kharki', 390019),
(5, 'AK Store', 'Mr.Sachin', 'Gotri', '7418529630', 'ak@ak.com', '123', 'shop/abt1.jpg', 'shop/arrowws.png', 'shop/banner2.jpg', 1, 'jobestan', 390012),
(6, 'sk fashion', 'kamlesh patel', 'Alkapuri', '9989898987', 'k@gmail.com', '123', '', '454', '6565', 1, 'Warshaw', 456);

-- --------------------------------------------------------

--
-- Table structure for table `user_reg`
--

CREATE TABLE `user_reg` (
  `u_id` int(5) NOT NULL,
  `u_fname` varchar(50) NOT NULL,
  `u_lname` varchar(50) NOT NULL,
  `u_address` varchar(100) NOT NULL,
  `u_email` varchar(50) NOT NULL,
  `u_pass` varchar(20) NOT NULL,
  `u_mob` varchar(12) NOT NULL,
  `u_status` int(2) NOT NULL,
  `area` varchar(200) NOT NULL,
  `pin` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_reg`
--

INSERT INTO `user_reg` (`u_id`, `u_fname`, `u_lname`, `u_address`, `u_email`, `u_pass`, `u_mob`, `u_status`, `area`, `pin`) VALUES
(1, 'Antony', 'sharpov', 'OGRODOWA 49 in warszawa', 'buyer@gmail.com', 'buyer', '7418529630', 1, 'warshaw', 124578);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `item_master`
--
ALTER TABLE `item_master`
  ADD PRIMARY KEY (`it_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `shopowner`
--
ALTER TABLE `shopowner`
  ADD PRIMARY KEY (`sh_id`);

--
-- Indexes for table `user_reg`
--
ALTER TABLE `user_reg`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `item_master`
--
ALTER TABLE `item_master`
  MODIFY `it_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `o_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `shopowner`
--
ALTER TABLE `shopowner`
  MODIFY `sh_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_reg`
--
ALTER TABLE `user_reg`
  MODIFY `u_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
