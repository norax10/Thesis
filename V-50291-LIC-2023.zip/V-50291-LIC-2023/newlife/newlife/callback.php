<?php session_start();
  include('connection.php');
 //$total_amount = $_POST['total_amount'];
 $cust_id= $_SESSION['u_id'];
 $order_id=strtotime("now");
 $_SESSION['order_no']= $order_id;
 
  $query1="select * from cart where cust_id='$cust_id'";
        
          $result2 = mysqli_query($conn,$query1);

           
        while($row=mysqli_fetch_array($result2)){
            $cust_id= $row['cust_id'];
            $r_id= $row['sh_id'];
            $product_id= $row['it_id'];
            $price= $row['price'];
			$subc_id= $row['subc_id'];
            $qty = $row['qty'];
           
      $insert_sql = "INSERT INTO orders (order_number,cust_id,sh_id,it_id,price,qty) VALUES ('$order_id','$cust_id','$r_id','$product_id','$price','$qty')";
	 
	 
            $result1 = mysqli_query($conn,$insert_sql);
			 echo "<script>alert('your order is confirm!')</script>";
			  echo"<script>window.open('index.php','_self')</script>";

		}
          

 $sqll="delete from cart where cust_id='$cust_id'";
        $result4 = mysqli_query($conn,$sqll);
   
   
    


?>	


 