<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<?php

include 'connection.php';
$user_id=$_GET['uid'];
$q = "SELECT * from item_master where it_id='$user_id' and it_status=1";
//session_start();

//$q = "SELECT * from item_master";
$data = mysqli_query($conn, $q);
$result = mysqli_num_rows($data);


?>
<html>

<?php include('head.php');?>
<body>
<!-- header -->
 <?php include('header.php');?>
<!-- //breadcrumbs -->
	<div class="products">


		
		<div class="container">
		
		 <?php

                    if ($result != 0) {
 
                      $i = 1;
                      while ($total = mysqli_fetch_assoc($data)) { ?>
			<div class="agileinfo_single">
				
				<div class="col-md-3 agileinfo_single_left" style="height : 430px;">
					<center>
											<img title=" " alt=" " src="./student/<?php echo $total["im1"]; ?>" height="140px" > 
<ul id="demo1"><br>
	<h4><?php echo $total["it_name"]; ?></h4>
	<div class="w3agile_description">
						
						<p style = "color:black"><?php echo $total["it_desc"]; ?></p>
					
					<div>
							<h4>Rs. <?php echo $total["it_price"]; ?> /- </h4>
						</div><br>
						<div class="snipcart-details" >
							<a class="button" href="cart.php?uid=<?php echo $total["it_id"]; ?>"><input type="button" name="submit" value="Add to Cart" class="button"></a>
						</div>
			
		 
	 
</ul>			
				</center>
				</div>
				</div>
				
				<div class="clearfix"> </div>
			</div>
			
			
			
				<?php } } ?>



		</div>
	</div>
<!-- new -->
	
<!-- //new -->
<!-- //footer -->
   <?php include('footer.php');?>

</body>
</html>