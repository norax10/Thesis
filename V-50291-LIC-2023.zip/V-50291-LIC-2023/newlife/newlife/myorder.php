
<!DOCTYPE html>
<?php
include 'connection.php';
session_start();
?>
<html>
<script src="js/jquery-1.11.1.min.js"></script>

<?php include('head.php');
	$a=$_SESSION['u_id'];
	?>
<body>
<!-- header -->
  <?php include('header.php');?>
	
<!-- //navigation -->
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">CheckOut</li>
			</ol>
		</div>
	</div>
<?php
$q = "SELECT a.*,b.* from orders as a,item_master as b  where a.cust_id='$a' and a.it_id =b.it_id";
$data6 = mysqli_query($conn, $q);
$result6 = mysqli_num_rows($data6);

?>
	<div class="checkout">
		<div class="container">
			<h2>Your Orders: <span><?php echo $result6; ?> Products</span></h2>
			<div class="checkout-right">
				<table class="timetable_sub">
					<thead>
						<tr>
							<th>SL No.</th>	
							<th>Order ID</th>	
							<th>Product Name</th>
							<th>Product Image</th>
							<th>Quantity</th>
							<th>Unit Price</th>
							<th>Sub Price</th>
							<th>Order Status </th>
							
						</tr>
					</thead>
					
					
					 <?php
$q = "SELECT a.*,b.* from orders as a,item_master as b  where a.cust_id='$a' and a.it_id =b.it_id";
$data = mysqli_query($conn, $q);
$result = mysqli_num_rows($data);
                    if ($result != 0) {
 
                      $i = 1;
                      while ($total = mysqli_fetch_assoc($data)) { ?>
					<tr class="rem1">
						<td class="invert"><?php echo $i ?></td>
							<td class="invert"><?php echo $total["order_number"]; ?> </td>
							<td class="invert"><?php echo $total["it_name"]; ?> </td>
						<td class="invert-image"><a href="#"><img src="./student/<?php echo $total["im1"]; ?>" alt=" " style="height:80px; width:80px" ></a></td>
						
						<td class="invert"><?php echo $total["qty"]; ?> </td>
						
						<td class="invert"><?php echo $total["it_price"]; ?> /-</td>
						<td class="invert"><?php echo $t=$total["qty"]* $total["it_price"]; ?> /-</td>
						<td class="invert"><?php    if($total["ostatus"]==0){ echo "<b style='color:orange'>Pending</b>"; }else{
							echo "<b style='color:Green'>Approved</b>";
						} ?></td>
							
					
					</tr>
					
				
				<?php $i++;} } ?>
								
				</table>
			</div>
			<div class="checkout-left">	
				<div class="checkout-left-basket">
					<h4><a href="index.php">Back to Home</a></h4>
				
				
			</div>
		</div>
	</div>
</div>





   <?php include('footer.php');?>
</body>
</html>