<!DOCTYPE html>
<?php

include 'connection.php';
session_start();
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<html lang="en">
<?php include('head.php');?>

<body>

    <?php include('header.php');?>
	  <?php include('menu.php');?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

          
            <!-- row -->

            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
							 <h4 class="card-title">Add Product</h4>
                                <div class="form-validation">
                                    <form class="form-valide" action="additem_process.php" method="post" enctype="multipart/form-data">
                                        
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-email">Item Name <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="val-email" name="item" placeholder="Your Item.." required>
                                            </div>
                                        </div>
										 <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-email">Item Description <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="val-email" name="itemdesc" placeholder="Your Item Description.." required>
                                            </div>
                                        </div>
																				 <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-email">Item Price <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-6">
                                                <input type="number" class="form-control" id="val-email" name="itemamt" placeholder="Your Item Price.." required>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-password">Item Image-1<span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-6">
                                                <input type="file" class="form-control" id="val-password" name="file1" required >
                                            </div>
                                        </div>
                                      
                                    
                                       <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-email">Item Remarks <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="val-email" name="itemremark" placeholder="Your Item Remarks.." required>
                                            </div>
                                        </div>
                                   
                                    
                                    
                                     
                                    
                                        <div class="form-group row">
                                            <div class="col-lg-8 ml-auto">
                                                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
        <!--**********************************
            Footer start
        ***********************************-->
       
   <?php include('footer.php');?>
</body>

<!-- Mirrored from demo.themefisher.com/quixlab/form-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2019 11:19:33 GMT -->
</html>