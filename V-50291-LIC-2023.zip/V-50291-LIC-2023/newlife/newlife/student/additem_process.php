
 <!DOCTYPE html>
<?php
   include "connection.php";
        
 
session_start();
if(isset($_POST['submit'])){
 
date_default_timezone_set('Asia/Kolkata');

$date = date('d/m/Y h:i:sa', time());

  $host='shop/';

    $item = $_POST['item'];
	$itemdesc = $_POST['itemdesc'];
		$itemamt = $_POST['itemamt'];
  
  $itemremark = $_POST['itemremark'];
  
  
  $id=$_SESSION['sh_id'];
  
  $fileinfo = basename($_FILES['file1']['name']);

  $file_path = $host.$fileinfo;
  $upload = $file_path;

  if(move_uploaded_file($_FILES['file1']['tmp_name'],$file_path) )
  {

      $conn->query("INSERT INTO `item_master`(`it_name`,`it_desc`,`it_price`,`im1`,`remark`,`it_status`,`sh_id`) VALUES('$item','$itemdesc','$itemamt','$upload','$itemremark' ,'1','  $id' )");
    echo "<script>alert('Item Added')</script>";
				 	echo"<script>window.open('dashboard.php','_self')</script>";
  }
        
}
      
?>
 
 
