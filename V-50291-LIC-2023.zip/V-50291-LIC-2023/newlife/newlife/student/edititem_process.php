
 <!DOCTYPE html>
<?php
   include "connection.php";
        
 
session_start();
if(isset($_POST['submit'])){
 
date_default_timezone_set('Asia/Kolkata');

$date = date('d/m/Y h:i:sa', time());

  $host='shop/';

    $item = $_POST['item'];
	$itemdesc = $_POST['itemdesc'];
		$itemamt = $_POST['itemamt'];
  
  $itemremark = $_POST['itemremark'];
 $it_id = $_POST['itid'];
  
  $id=$_SESSION['sh_id'];
  
  $fileinfo = basename($_FILES['file1']['name']);

  $file_path = $host.$fileinfo;
  $upload = $file_path;
  if(move_uploaded_file($_FILES['file1']['name'],$file_path) )
  {

      $conn->query("Update item_master it_name='$item',it_desc='$itemdesc',it_price='$itemamt' im1='$upload' where it_id='$it_id'");
   echo "<script>alert('Item Updated')</script>";
			 	echo"<script>window.open('viewitem.php','_self')</script>";
  }
  
  else
  {
	  
	  $conn->query("Update item_master set it_name='$item',it_desc='$itemdesc',it_price='$itemamt',im1='$upload' where it_id='$it_id'");
    echo "<script>alert('Item Updated')</script>";
				 	echo"<script>window.open('viewitem.php','_self')</script>";
	  
  }
        
}
       
?>
 
 
