<!DOCTYPE html>
<?php

include 'connection.php';

session_start();

if (!isset($_SESSION['sh_email'])) {
  header("location:login.php");
}
?>
<html lang="en">


<!-- Mirrored from demo.themefisher.com/quixlab/layout-one-column.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2019 11:18:12 GMT -->
<?php include('head.php');?>

<body>

    <?php include('header.php');?>
	  <?php include('menu.php');?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
       
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Home</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->
 <div class="row page-titles mx-0">
            <div class="container-fluid">
               
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
							 <div class="row">
							
                                   <div class="col-xl-3 col-sm-6 mb-3">
        <div class="card text-white bg-warning o-hidden h-100">
            <div class="card-body">					 <?php
			$a= $_SESSION['sh_id'];
$q6 = "SELECT * from item_master where sh_id = $a";
$data6 = mysqli_query($conn, $q6);
$result6 = mysqli_num_rows($data6);

?>
                <div class="card-body-icon">
                 <?php echo $result6; ?>
                </div>
                <div class="mr-5">Total Product</div>
            </div>
           
        </div>
    </div>
	
	<!--div class="col-xl-3 col-sm-6 mb-3">
        <div class="card text-white bg-warning o-hidden h-100">
            <div class="card-body">	 <?php
			
$q7 = "SELECT distinct(sub_id) from sub_category where sh_id='$a'";
$data7 = mysqli_query($conn, $q7);
$result7 = mysqli_num_rows($data7);

?>
  
                <div class="card-body-icon">
                  <?php echo $result7; ?>
                </div>
                <div class="mr-5">Total Active Sub Categories</div>
            </div>
           
        </div>
    </div--->
	
                            </div></div>
                        </div>
                  
                </div>
            </div></div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
       
  

   <?php include('footer.php');?>
</body>


<!-- Mirrored from demo.themefisher.com/quixlab/layout-one-column.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2019 11:18:12 GMT -->
</html>