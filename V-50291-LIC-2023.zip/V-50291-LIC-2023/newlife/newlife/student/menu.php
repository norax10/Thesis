
<!DOCTYPE html>
<html lang="zxx">

<?php 

//session_start();


include('head.php');?>

 <div class="nk-sidebar">           
            <div class="nk-nav-scroll">
                <ul class="metismenu" id="menu">
                   
                    <li>
                        <a href="dashboard.php">
                            <i class="icon-speedometer menu-icon"></i><span class="nav-text">Dashboard</span>
                        </a>
                       
                    </li>
                    
                     
					  <li>
                        <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                            <i class="icon-note menu-icon"></i><span class="nav-text">Manage Item</span>
                        </a>
                        <ul aria-expanded="false">
                            
                            <li><a href="additem.php">Add Item</a></li>
							<li><a href="viewitem.php">View Item</a></li>
                           
                        </ul>
                    </li>
                    <li>
                        <a class="has-arrow" href="javascript:void()" aria-expanded="false">
                            <i class="icon-note menu-icon"></i><span class="nav-text">Manage Orders</span>
                        </a>
                        <ul aria-expanded="false">
                            
                      
							<li><a href="vieworders.php">View Orders</a></li>
                           
                        </ul>
                    </li>
                   
                    
                </ul>
            </div>
        </div>

	