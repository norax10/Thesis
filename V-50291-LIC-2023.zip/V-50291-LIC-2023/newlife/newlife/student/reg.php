
 <!DOCTYPE html>
<?php
   include "connection.php";
        
 

if(isset($_POST['submit'])){
 
date_default_timezone_set('Asia/Kolkata');

$date = date('d/m/Y h:i:sa', time());

  $host='shop/';

  $shname = $_POST['shname'];
    $shoname = $_POST['shoname'];
	  $shadd = $_POST['shadd'];
	    $shmob = $_POST['shmob'];
		
		  $shemail = $_POST['shemail'];
		    $shpass = $_POST['shpass'];
  
  $sharea = $_POST['sharea'];
   $shpin = $_POST['shpin'];
  
  
  
  $fileinfo = basename($_FILES['shlogo']['name']);

  $file_path = $host.$fileinfo;
  $upload = $file_path;

  $fileinfo1 = basename($_FILES['shpan']['name']);

  $file_path1 = $host.$fileinfo1;
  $upload1 = $file_path1;
  
   $fileinfo2 = basename($_FILES['shrim']['name']);

  $file_path2 = $host.$fileinfo2;
  $upload2 = $file_path2; 

  if(move_uploaded_file($_FILES['shlogo']['tmp_name'],$file_path) && move_uploaded_file($_FILES['shpan']['tmp_name'],$file_path1) && move_uploaded_file($_FILES['shrim']['tmp_name'],$file_path2)){

      $conn->query("INSERT INTO `shopowner`(`sh_name`, `sh_oname`,`sh_address`,`sh_mob`,`sh_email`,`sh_pass`,`sh_image`,`sh_pan`,`sh_regim`,`sh_status`,`sharea`,`shpin`) VALUES('$shname','$shoname','$shadd','$shmob','$shemail','$shpass','$upload','$upload1','$upload2','0','$sharea','$shpin')");
      header('location:login.php');
  }
        
}




  
        
?>
 
 
