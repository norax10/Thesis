<!DOCTYPE html>
<?php

include 'connection.php';

session_start();

if (!isset($_SESSION['sh_email'])) {
  header("location:login.php");
}

$id=$_SESSION['sh_id'];
$it_id=$_GET['it_id'];

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<html lang="en">


<!-- Mirrored from demo.themefisher.com/quixlab/form-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2019 11:19:32 GMT -->
<?php include('head.php');?>

<body>

    <?php include('header.php');?>
	  <?php include('menu.php');?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

          
            <!-- row -->

            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="form-validation">
                                    <form class="form-valide" action="edititem_process.php" method="post" enctype="multipart/form-data">
                                       
										 
										
										<?php $q4 = "SELECT * from item_master where it_id='$it_id'";
$data4 = mysqli_query($conn, $q4);
$result4 = mysqli_num_rows($data4);
                if ($result4 != 0) {
 
                
                      while ($total4 = mysqli_fetch_assoc($data4)) {

                 
?>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-email">Item Name <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="val-email" name="item" placeholder="Your Item.." required value="<?php echo $total4['it_name'];?> ">
                                            </div>
                                        </div><input type="text" class="form-control" id="val-email" name="itid" placeholder="Your Item.." required value="<?php echo $total4['it_id'];?> " hidden>
										 <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-email">Item Description <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="val-email" name="itemdesc" placeholder="Your Item Description.." required   value="<?php echo $total4['it_desc'];?>">
                                            </div>
                                        </div>
																				 <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-email">Item Price <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-6">
                                                <input type="number" class="form-control" id="val-email" name="itemamt" placeholder="Your Item Price.." required   value="<?php echo $total4['it_price'];?>" >
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-password">Item Image-1<span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-6">
                                                <input type="file" class="form-control" id="val-password" name="file1"  >
                                            </div>
											<img src="<?php echo $total4["im1"]; ?>" width='80' height='60' alt='icon'>
                                        </div>
                                         
                                    
                                       <div class="form-group row">
                                            <label class="col-lg-4 col-form-label" for="val-email">Item Remarks <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" id="val-email" name="itemremark" placeholder="Your Item Remarks.." required value="<?php echo $total4["it_desc"]; ?>">
                                            </div>
                                        </div>
                                   
                                      <?php   }} ?>
                                    
                                     
                                    
                                        <div class="form-group row">
                                            <div class="col-lg-8 ml-auto">
                                                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
        <!--**********************************
            Footer start
        ***********************************-->
       
   <?php include('footer.php');?>
</body>
<script>
function getSubCategory(val) {
	//alert(val);
	$.ajax({
		type: "POST",
		url: "get-subcat.php",
		data:'cat_id='+val,
		beforeSend: function() {
			$("#subcat").addClass("loader");
		},
		success: function(data){
			$("#subcat").html(data);
			
			$("#subcat").removeClass("loader");
		}
	});
}


</script>

<!-- Mirrored from demo.themefisher.com/quixlab/form-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2019 11:19:33 GMT -->
</html>