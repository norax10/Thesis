<!DOCTYPE html>
<?php

include 'connection.php';


session_start();

if (!isset($_SESSION['sh_id'])) {
  header("location:login.php");
}
$id=$_SESSION['sh_id'];


$q = "SELECT * from item_master where sh_id=$id ";
$data = mysqli_query($conn, $q);
$result = mysqli_num_rows($data);

//select* from category


//select * from sub_category where category_id and customer_id 


?>
<html lang="en">


<!-- Mirrored from demo.themefisher.com/quixlab/table-datatable.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2019 11:19:49 GMT -->
<?php include('head.php');?>

<body>

    <!--*******************
        Preloader start
    ********************-->
      <?php include('header.php');?>
	  <?php include('menu.php');?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
    
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

          
      
	  
	  <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">View Product</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
											 <th>S.N.</th>
                                                <th>Item Name</th>
                                                <th>Item Price</th>
                                                 <th>Item Image</th>
												   <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <?php

                    if ($result != 0) {
 
                      $i = 1;
                      while ($total = mysqli_fetch_assoc($data)) {

                 
?>
                        
         
                  <tr>
                    <td><?php echo $i ;?></td>
                    <td><?php echo $total["it_name"]; ?></td>
					    <td><?php echo $total["it_price"]; ?>/-</td>
                    <td class='text-center'><img src="<?php echo $total["im1"]; ?>" width='80' height='60' alt='icon'></td>
                 <td> <a href="edititem.php?it_id=<?php echo $total['it_id'];?>" class="btn btn-primary"> EDIT </a></td>
                    </tr>

					<?php  $i++; }} ?>
                                    </tbody>
                                        
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	  
	  
	  
            </div>
      
       <?php include('footer.php');?>

</body>


<!-- Mirrored from demo.themefisher.com/quixlab/table-datatable.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2019 11:19:50 GMT -->
</html>