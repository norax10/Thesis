<!DOCTYPE html>
<?php
 
$host="localhost";
$user="root";
$password="";
$db="newlife";
 

$conn=mysqli_connect($host, $user, $password, $db);

if($conn){
    
    
    
}


?>