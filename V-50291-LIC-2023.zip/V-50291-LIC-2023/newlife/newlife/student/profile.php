<!DOCTYPE html>
<?php

include 'connection.php';

session_start();

if (!isset($_SESSION['sh_email'])) {
  header("location:login.php");
}
$id=$_SESSION['sh_id'];

$q = "SELECT * FROM shopowner where sh_id='$id'";
$data = mysqli_query($conn, $q);
$result = mysqli_num_rows($data);
?>
<html lang="en">


<!-- Mirrored from demo.themefisher.com/quixlab/form-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2019 11:19:32 GMT -->
<?php include('head.php');?>

<body>

    <?php include('header.php');?>
	  <?php include('menu.php');?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard.php">Profile</a></li>
                    </ol>
                </div>
            </div>
            <!-- row -->

            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="form-validation"><?php  if ($result != 0) {
 
                      $i = 1;
                      while ($total = mysqli_fetch_assoc($data)) { ?>

                                    <form class="form-valide" action="profile_process.php" method="post" enctype="multipart/form-data">
                                        
                                    <div class="form-group row">
									<div class="col-lg-6">
                                        <input type="text" class="form-control"  placeholder="Shop Name" name="shname" readonly value="<?php echo $total["sh_name"]; ?>">
                                    </div>  
<div class="col-lg-6">
                                        <input type="text" class="form-control"  placeholder="Shop Owner Name" name="shoname" readonly value="<?php echo $total["sh_oname"]; ?>">
                                    </div>
									</div>
								
								 <div class="form-group row">
									<div class="col-lg-6">
                                        <input type="text" class="form-control"  placeholder="Shop Address" name="shadd"  value="<?php echo $total["sh_address"]; ?>">
                                    </div>
									<div class="col-lg-6">
                                        <input type="text" class="form-control"  placeholder="Shop Area" name="sharea"  value="<?php echo $total["sharea"]; ?>">
                                    </div>
									</div>
									 <div class="form-group row">
									
									<div class="col-lg-6">
                                        <input type="text" class="form-control"  placeholder="Pin" name="shpin"  value="<?php echo $total["shpin"]; ?>">
                                    </div>
									<div class="col-lg-6">
                                        <input type="number" class="form-control"  placeholder="Shop Contact Number" name="shmob"  readonly value="<?php echo $total["sh_mob"]; ?>">
                                    </div>
									</div>
								 
									
                                  <div class="form-group row">
									<div class="col-lg-6">
                                        <input type="email" class="form-control"  placeholder="Email" name="shemail" readonly value="<?php echo $total["sh_email"]; ?>">
                                    </div>
									<div class="col-lg-6">
                                        <input type="text" class="form-control" placeholder="Password" name="shpass"  value="<?php echo $total["sh_pass"]; ?>">
                                    </div>
									</div>
                                    
									  <div class="form-group row">
									<div class="col-lg-6"><label class="col-lg-4 col-form-label" for="val-skill">Shop Image
                                            </label>
                                        <img src="../student/<?php echo $total["sh_image"]; ?>" alt=" "  width="80px" height="60px" />
                                    </div>
									
									
									<div class="col-lg-6"><label class="col-lg-4 col-form-label" for="val-skill">Shop PAN Image
                                            </label>
                                       <img src="../student/<?php echo $total["sh_pan"]; ?>" alt=" "  width="80px" height="60px" />
                                    </div>
									
									
									</div>
									
									 <div class="form-group row">
									<div class="col-lg-6"><label class="col-lg-4 col-form-label" for="val-skill">Shop Registration
                                            </label>
                                       <img src="../student/<?php echo $total["sh_regim"]; ?>" alt=" "  width="80px" height="60px" />
                                    </div></div>
									<input type="text" class="form-control"  placeholder="Shop Name" name="shid1" hidden value="<?php echo $id ?>">
                                    <button class="btn login-form__btn submit w-100" name="submit">Submit</button>
                                </form>
                                        
					  </form> 	<?php }  } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #/ container -->
        </div>
        <!--**********************************
            Content body end
        ***********************************-->
        
        
        <!--**********************************
            Footer start
        ***********************************-->
       
   <?php include('footer.php');?>
</body>


<!-- Mirrored from demo.themefisher.com/quixlab/form-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2019 11:19:33 GMT -->
</html>