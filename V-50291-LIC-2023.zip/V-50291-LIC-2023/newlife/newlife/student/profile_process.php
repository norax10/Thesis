
 <!DOCTYPE html>
<?php
   include "connection.php";
        
 
session_start();
if(isset($_POST['submit'])){
 
date_default_timezone_set('Asia/Kolkata');

$date = date('d/m/Y h:i:sa', time());

$host='shop/';
$shadd=$_POST['shadd'];
$sharea = $_POST['sharea'];
$shpin = $_POST['shpin'];
$shpass = $_POST['shpass'];
$id=$_POST['shid1'];
 
   $conn->query("Update shopowner set sh_address='$shadd',sharea='$sharea',shpin='$shpin',sh_pass='$shpass' where  sh_id='$id' ");
    echo "<script>alert('Profile Updated')</script>";
	echo"<script>window.open('dashboard.php','_self')</script>";
 
        
}




  
        
?>
 
 
