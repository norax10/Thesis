<!DOCTYPE html>
<?php

include 'connection.php';


session_start();

if (!isset($_SESSION['sh_id'])) {
  header("location:login.php");
}
$id=$_SESSION['sh_id'];
$img_url = "c_image";
?>
<html lang="en">


<!-- Mirrored from demo.themefisher.com/quixlab/table-datatable.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Dec 2019 11:19:49 GMT -->
<?php include('head.php');?>

<body>

    <!--*******************
        Preloader start
    ********************-->
      <?php include('header.php');?>
	  <?php include('menu.php');?>
        
        <div class="content-body">

            <div class="row page-titles mx-0">
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                      
                    </ol>
                </div>
            </div>
      
	  
	  <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">View Orders</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                      <tr>
							<th>#</th>	
							<th>Order ID</th>	
							<th>Customer Name</th>	
							<th>Product Name</th>
							<th>Product Img</th>
							<th>Qty</th>
							
						
							<th>Unit</th>
								<th>Sub Price</th>
							<th>Action</th>
						</tr>
                                        </thead>
                                        <tbody>
                                           <?php
$q = "SELECT b.*,c.*,d.* from orders as b ,user_reg as c ,item_master as d where b.sh_id=$id and b.cust_id=c.u_id and d.it_id=b.it_id";
$data = mysqli_query($conn, $q);
$result = mysqli_num_rows($data);
                    if ($result != 0) {
 
                      $i = 1;
                      while ($total = mysqli_fetch_assoc($data)) { ?>

                   
         
                  <tr>
                    <td><?php echo $i ?></td>
				   <td><?php echo $total["order_number"]; ?></td>
                    <td><?php echo $total["u_fname"]." ".$total["u_lname"]; ?></td>
					   
					    <td><?php echo $total["it_name"]; ?></td>
                    <td class='text-center'><img src="../student/<?php echo $total["im1"]; ?>" alt=" "  width="80px" height="60px" /></td>
                   <td class="invert"><?php echo $total["qty"]; ?> </td>
						
						<td class="invert"><?php echo $total["it_price"]; ?> /-</td>
						<td class="invert"><?php echo $t=$total["qty"]* $total["it_price"]; ?> /-</td>
						
					  <td class="invert"><?php if ($total["ostatus"]=='0') {?>
<a href="approve.php?catid=<?php echo $total['o_id'];?>" class="btn btn-danger"> PENDING </a>
				 <?php 	  }
					 
					  else
					  { ?>
						   <a href="#" class="btn btn-primary"> APPROVED </a>
						    
					<?php   } ?><br><br>
						  
						  
						 
						  </td> 
                    </tr>

     	<?php $i++;} } ?> 
                                        </tbody>
                                      
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	  
	  
	  
            </div>
      
       <?php include('footer.php');?>

</body>

 
</html>