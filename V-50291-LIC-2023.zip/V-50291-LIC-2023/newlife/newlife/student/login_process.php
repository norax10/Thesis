<?php

include('connection.php');
	
		$email=$_POST['username'];
		$pass=$_POST['pwd'];
		

		 $sql = "SELECT * FROM shopowner WHERE sh_email='$email' and sh_pass='$pass' ";
		
		$result = mysqli_query($conn,$sql);
		if(mysqli_num_rows($result) > 0)
	{
			while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
			{
				
				if($row["sh_status"]==0)
				{
					 echo "<script>alert('Your account has been on hold by admin!!!!')</script>";
				 	echo"<script>window.open('login.php','_self')</script>";
				}
				
				else
				{
session_start();
			$email = $row['sh_email'];
			$_SESSION['sh_email']=$email;
				
			
			$name = $row['sh_name'];
			  $_SESSION['sh_name']=$name;
			  
			  $shoname = $row['sh_oname'];
			  $_SESSION['sh_oname']=$shoname;
			 
		
		 $id = $row['sh_id'];
			 $_SESSION['sh_id']=$id;
			  $im = $row['sh_image'];
			 $_SESSION['sh_image']=$im;
		}
	
		 	echo"<script>window.open('dashboard.php','_self')</script>";
			//header("Location:index.php"); 
	
    }
	}
    else
    {
           echo "<script>alert('Invalid Email or Password')</script>";
				 	echo"<script>window.open('login.php','_self')</script>";
		
			//header("Location: c_login.php"); 
				
	}
			
			
			
			
			
  
?>
