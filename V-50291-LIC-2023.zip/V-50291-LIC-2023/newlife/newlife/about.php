
<!DOCTYPE html>
<html>
<?php include('head.php');
session_start();?>
<body>
<!-- header -->
  <?php include('header.php');?>
		
<!-- //navigation -->
	<!-- main-slider -->
		
		
			<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.php"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">About</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- about -->	
	<div class="about">
		<div class="container">
			<h3 class="w3_agile_header">About Us</h3>
			<div class="about-agileinfo w3layouts">
				<div class="col-md-8 about-wthree-grids grid-top">
					<h4>New Life for Old Products:A place for everyone!!!!! </h4>
					<p class="top">New Life for Old Products is a platform where customers can have their local markets on their screens. An ecommerce website where shop owners will display their products for sell and customers can purchase it by having them packed and self picking. Customers can check the availability of the product they want to purchase and also order them with just fingertips. Customer also gets features like 'mini kit' where they can store all  essentials and can purchase on one click by checking the availability and price differences. We'll remind them a day before, through notifications and email, just in case they forget. So this way, with features like, mini kit , reminders and self picking, shopping would be a lot easier.  </p>		
					
				</div>
				<div class="col-md-4 about-wthree-grids">
					<div class="offic-time">
						<div class="time-top">
							<h4>Contact US :</h4>
						</div>
						<div class="time-bottom">
							<h5>Email US: </h5>
							<h5>abc@gmail.com</h5>
							<hr>
							<h5>Mobile: </h5>
							<h5>+74185296321550</h5>
						</div>
					</div>
					
				</div>	
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
		
		
   <?php include('footer.php');?>
</body>
</html>