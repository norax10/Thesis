	

<?php
   
include 'connection.php';
//session_start();
?>
<div class="agileits_header">
		<div class="container"><?php  if (isset($_SESSION['u_email'])) { ?>
			<div class="w3l_offers">
				<h2> Welcome  <?php echo $_SESSION['u_fname'] ?></h2>
			</div>	<?php	} ?>
			<div class="agile-login">
				<ul><?php 
if (!isset($_SESSION['u_email'])) { ?>
					<li><a href="register.php"> Create Account </a></li>

					<li><a href="login.php">Login</a></li>
					<!---a href="admin/login.php">
											<img src="images/admin.png" alt="" height="30px" title="Admin Login">
										</a--->
					<a href="student/login.php">
											<img src="images/store.png" alt="" height="30px" title="Store Manager Login">
										</a>

				<?php } else  {  ?>
					
						<li><a href="logout.php">Logout</a></li>
						<li><a href="myorder.php">My Orders</a></li>
			<?php	} ?>
					
				</ul>
			</div>
			<div class="product_list_header">  
					<form action="viewc.php" method="post" class="last"> 
				
						<button class="w3view-cart" type="submit" name="submit"  title ="My Cart" value=""><img src="images/mycart.png" height="35"></button>
						<?php 
if (isset($_SESSION['u_email'])) { ?>
						
<?php } ?>
					</form>  
					
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>

	<div class="logo_products">
		<div class="container">
		<div class="w3ls_logo_products_left1">
				<ul class="phone_email">
					<li><i class="fa fa-phone" aria-hidden="true"></i>Order online or call us : (+0123) 234 567</li>
					
				</ul>
			</div>
			<div class="w3ls_logo_products_left">
				<h1><a href="index.php">New Life</a></h1>
			</div>
		<!----div class="w3l_search">
			<form action="index.php" method="post">
				<input type="search" name="search" placeholder="Search for a Store..." required="">
				<button type="submit" class="btn btn-default search" name="searchbtn" aria-label="Left Align">
					<i class="fa fa-search" aria-hidden="true"> </i>
				</button>
				<div class="clearfix"></div>
			</form>
		</div---->
			
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //header -->
<!-- navigation -->
	<div class="navigation-agileits">
		<div class="container">
			<nav class="navbar navbar-default">
							<!-- Brand and toggle get grouped for better mobile display -->
							<div class="navbar-header nav_2">
								<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
							</div> 
							<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
								<ul class="nav navbar-nav">
									<li class="active"><a href="index.php" class="act">Home</a></li>
									
								<li class="active"><a href="Product.php" class="act">Product</a></li>
								
									<!-- Mega Menu -->
									
								
									
									<li><a href="about.php">About Us</a></li>
									
								</ul>
							</div>
							</nav>
			</div>
		</div>