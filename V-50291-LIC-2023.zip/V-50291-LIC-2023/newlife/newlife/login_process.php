<?php

include('connection.php');	
	
		$email=$_POST['email'];
		$pass=$_POST['pass'];
		
		$sql = "SELECT * FROM user_reg WHERE u_email='$email' and u_pass='$pass' ";
		
		$result = mysqli_query($conn,$sql);
		if(mysqli_num_rows($result) > 0)
	{
			while($row = mysqli_fetch_array($result,MYSQLI_ASSOC))
			{
				
				if($row["u_status"]==0)
				{
					 echo "<script>alert('Your account has been on hold by admin!!!!')</script>";
				 	echo"<script>window.open('login.php','_self')</script>";
				}
				
				else
				{
session_start();
			$email = $row['u_email'];
			$_SESSION['u_email']=$email;
				
			
			$name = $row['u_fname'];
			  $_SESSION['u_fname']=$name;
		
		 $id = $row['u_id'];
			 $_SESSION['u_id']=$id;
			 
			  $id = $row['area'];
			 $_SESSION['area']=$id;
			 
			  $id = $row['pin'];
			 $_SESSION['pin']=$id;
			
		}
	
		 	echo"<script>window.open('index.php','_self')</script>";
			//header("Location:index.php"); 
	
    }
	}
    else
    {
           echo "<script>alert('Invalid Email or Password')</script>";
				 	echo"<script>window.open('login.php','_self')</script>";
		
			
				
	}
			 
?>
