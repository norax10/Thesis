<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<?php include('head.php');?>
	
<body>
<!-- header -->
  <?php include('header.php');?>
<!-- //breadcrumbs -->
<!-- register -->
	<div class="register">
		<div class="container">
			<h2>Register Here</h2>
			<div class="login-form-grids">
				<h5>profile information</h5>
				<form action="reg_process.php" method="post">
					<input type="text" placeholder="First Name..." onkeypress="return (event.charCode > 64 && event.charCode < 91 ) || (event.charCode > 96 && event.charCode < 123 ) || (event.charCode == 32)" required=" " name="fname" >
					
					<input type="text" placeholder="Last Name..." onkeypress="return (event.charCode > 64 && event.charCode < 91 ) || (event.charCode > 96 && event.charCode < 123 ) || (event.charCode == 32)" required=" " name="lname" >
					
						<input type="text" placeholder="Mobile"  required=" " name="mob" onkeypress='return event.charCode >= 48 && event.charCode <= 57'><br>
						<input type="text" placeholder="Address..." required=" " name="add"><br>
							<input type="text" placeholder="Area..." required=" " name="area"><br>
			<input type="text" placeholder="Pin Code" required=" " name="pin" max="6" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
			
				
				<h6>Login information</h6>
				
					<input type="email" placeholder="Email Address" required=" " name="email">
					<input type="password" placeholder="Password" required=" " name="pass" ><br>
						<input type="submit" value="Register"  name="submit">
				</form>
			</div>
			<div class="register-home">
				<a href="index.php">Home</a>
			</div>
		</div>
	</div>
<!-- //register -->
<!-- //footer -->
<?php include('footer.php');?>

</body>
</html>
<script>
    function isNumberKey(evt){
        var charCode = (evt.which) ? evt.which : evt.keyCode
        return !(charCode > 31 && (charCode < 48 || charCode > 57));
    }
    
    function alphaOnly(event) {
        var key = event.keyCode;
        return ((key >= 65 && key <= 90) || (event.keyCode > 96 && event.keyCode < 123) || key == 8);
    };
</script>