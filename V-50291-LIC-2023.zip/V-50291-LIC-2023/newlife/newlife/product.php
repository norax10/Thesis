 
<?php

include 'connection.php';
session_start();
$q = "SELECT * from item_master";
$data = mysqli_query($conn, $q);
$result = mysqli_num_rows($data);

?>
<html>
 
<?php include('head.php');?>
	
<body>
<!-- header -->
  <?php include('header.php');?>
		
<!-- //navigation -->
<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				
				
			</ol>
		</div>
	</div>

	<div class="newproducts-w3agile">
		
			<h3>Products</h3><br>
				<div class = "row">
				<div class = "col-md-2 product">
				
				
				<div class="categories">
					<h2>Area</h2>
					
						 <?php
						 
						$q1 = "SELECT distinct(sharea) from shopowner";	
						
						$data1 = mysqli_query($conn, $q1);
						$result1 = mysqli_num_rows($data1);

                    if ($result1 > 0) {
 
                      $i = 1;
                      while ($total1 = mysqli_fetch_assoc($data1)) { 
					  
					 
					  ?>
					
					<ul class="cate">
				
						
						<li><a href="product.php?sharea=<?php echo $total1["sharea"]; ?>"><i class="fa fa-arrow-right" aria-hidden="true"><?php echo $total1["sharea"]; ?></i></a></li>
						
						
				
					</ul>
					
							 <?php } } ?>
				</div>
				
				</div>
				
				<div class = "col-md-10 product">
				<div class="agile_top_brands_grids">
					
				 <?php
				 if(isset($_GET['sharea'])){
				 $sharea=$_GET['sharea'];
				 //echo "hiii";
 $q3 = "SELECT a.*,b.* from item_master as a,shopowner as b  where b.sharea='$sharea' and a.sh_id=b.sh_id";
$data3 = mysqli_query($conn, $q3);
$result3 = mysqli_num_rows($data3);
           }
		   
		   else
		   {
			
			$q3 = "SELECT * from item_master";
			$data3 = mysqli_query($conn, $q3);
			$result3 = mysqli_num_rows($data3);

		   }


			
                    if ($result3 != 0) {
 
                      $i = 1;
                      while ($total1 = mysqli_fetch_assoc($data3)) { ?>
					<div class="col-md-3 top_brand_left-1" style = "padding:10px">
						<div class="hover14 column">
							<div class="agile_top_brand_left_grid">
								<div class="agile_top_brand_left_grid_pos">
									
								</div>
								<div class="agile_top_brand_left_grid1">
									
									
									<!--a class="button" href="viewdetails.php?uid=<?php echo $total1["it_id"]; ?>&shid=<?php echo $total1["sh_id"]; ?>"---><figure>
									
										<div class="snipcart-item block">
									
											<div class="snipcart-thumb">
												<img title=" " alt="Product Image" src="./student/<?php echo $total1["im1"]; ?>" height="170px"> <br>
												
												<p style="color:#1B4F72; font-weight:bold;font-size:16px;"><?php echo $total1["it_name"]; ?></p>
												
													<h4><?php echo $total1["it_desc"]; ?></h4>
											</div>
											
											<div class="snipcart-details top_brand_home_details">
												
		<a class="button" href="viewmoredetails.php?uid=<?php echo $total1["it_id"]; ?>&shid = <?php echo $total1["it_id"];?>"><input type="button" name="submit" value="View Details" class="button"></a>
		
		
		
		
		
											</div>
										</div>
										
									</figure>
									</a>
								</div>
							</div>
						</div>
					</div>
					<?php } } else {?>
					
					<h2>Products are not available</h2> <?php } ?>
				
					
					
						<div class="clearfix"> </div>
						</div>
				</div>
				</div>
				
				
				
				
		</div>

<div>
   <?php include('footer.php');?>
</div>
</body>
</html>