
 <!DOCTYPE html>
<?php
   include "connection.php";
        
 

if(isset($_POST['submit'])){
 
date_default_timezone_set('Asia/Kolkata');

$date = date('d/m/Y h:i:sa', time());

  $host='shop/';

  $fname = $_POST['fname'];
    $lname = $_POST['lname'];
	  $add = $_POST['add'];
	    $email = $_POST['email'];
		
		  $pass = $_POST['pass'];
		    $mob = $_POST['mob'];
  
  $area = $_POST['area'];
  $pin = $_POST['pin'];
  
 
      $conn->query("INSERT INTO `user_reg`(`u_fname`, `u_lname`,`u_address`,`u_email`,`u_pass`,`u_mob`,`u_status`,`area`,`pin`) VALUES('$fname','$lname','$add','$email','$pass','$mob','1','$area','$pin')");
	  
	  echo "<script>alert('Registration Sucessfully!')</script>";
     echo"<script>window.open('login.php','_self')</script>";
 
        
}




  
        
?>
 
 
