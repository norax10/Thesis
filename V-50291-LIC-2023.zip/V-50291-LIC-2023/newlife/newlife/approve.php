
<?php

        session_start();

        if(!isset($_SESSION['sh_id'])){

            header("location:login.php");
        }


        include('connection.php');
        
         $user_id=$_GET['catid'];



       $q="select ostatus from shopowner where o_id='$user_id'";
		$data=mysqli_query($conn,$q);
		$total=mysqli_fetch_assoc($data);
		if($total['ostatus']==0){
			
			 $updateque="update orders set ostatus=1 where o_id='$user_id'"; 
             $result=mysqli_query($conn,$updateque);
            
             if($result){             
                header('location:vieworders.php');
                }
		}
		
 
    
  
    
?>